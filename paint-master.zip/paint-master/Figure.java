import java.awt.Color;
import java.awt.*;

public abstract class Figure{
  public boolean rempli;
  public Color couleur;
  public int taille;
  public int groupID;

  public Figure(boolean rempli, Color couleur, int taille, int groupID){
    this.groupID = groupID;
    this.rempli = rempli;
    this.couleur = couleur;
    this.taille = taille;
  }

  public abstract void dessiner(Graphics g);
}
