import java.awt.*;
import javax.swing.*;
import java.util.*;



public class ZoneDessin extends JPanel {
  public ArrayList<Figure> element;

  public ZoneDessin(ArrayList<Figure> element){
    super();
    this.element = element;
    this.setOpaque(true);
    this.setVisible(true);
    setBackground(Color.WHITE);
  }

  public void paintComponent(Graphics g){
    super.paintComponent(g);
    Iterator<Figure> iterator = element.iterator();
    while(iterator.hasNext()){
      Figure f = iterator.next();
      f.dessiner(g);
    }
  }
}
