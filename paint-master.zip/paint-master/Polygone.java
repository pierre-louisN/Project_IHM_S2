import java.awt.Color;
import java.awt.*;
import java.lang.Math;

public class Polygone extends Figure {
  public int[] x;
  public int[] y;
  public int nPoint;


  public Polygone(int[] x, int[] y, int nPoint, boolean rempli, Color couleur, int taille, int groupID) {
  	super(rempli, couleur, taille, groupID);
    this.x = x;
    this.y = y;
    this.nPoint = nPoint;
  }

  public void dessiner(Graphics g){
    g.setColor(this.couleur);
    ((Graphics2D) g).setStroke(new BasicStroke(this.taille));

    if (this.rempli)
      g.fillPolygon(x, y, nPoint);
    else
      g.drawPolygon(x, y, nPoint);
  }
}
