import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.awt.Color;
import javax.swing.event.*;


public class Fenetre extends JFrame{
  private ArrayList<Figure> element;
  private boolean remplir = false;
  private String figure = "Ligne";
  private Color couleur = Color.BLACK;
  private int taille = 2;
  private JToggleButton crayonModeB;
  private JToggleButton figureModeB;
  private JToggleButton gommeModeB;
  private int mode = CRAYON;
  private CurseurListener curseurListener;
  private DrawListener drawListener;
  private Integer x1;
  private Integer y1;
  private int[] x = new int[1000];
  private int[] y = new int[1000];
  private int nPoint = 0;
  private int count = 1;
  private static int CRAYON = 1;
  private static int FIGURE = 2;
  private static int GOMME = 3;


  public Fenetre(){
    super();
    this.setTitle("Paint");
    this.setSize(1400, 800);
    this.setLocationRelativeTo(null);
    this.setResizable(false);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.element = new ArrayList<Figure>();
    this.curseurListener = new CurseurListener();
    this.drawListener = new DrawListener();
    this.refreshZoneDessin();
    this.initButton();
    this.setVisible(true);
  }

  public void refreshZoneDessin(){
    ZoneDessin z = new ZoneDessin(element);
    z.addMouseListener(this.curseurListener);
    z.addMouseMotionListener(this.drawListener);
    this.add(z, BorderLayout.CENTER);
  }

  public void initButton(){
    JPanel nPan = new JPanel();
    nPan.setBackground(Color.WHITE);

    ModeListener modeListener = new ModeListener();

    JToggleButton crayonModeB = new JToggleButton("Crayon", true);
    crayonModeB.addActionListener(modeListener);
    this.crayonModeB = crayonModeB;
    nPan.add(crayonModeB);

    JToggleButton figureModeB = new JToggleButton("Figures");
    figureModeB.addActionListener(modeListener);
    this.figureModeB = figureModeB;
    nPan.add(figureModeB);

    JToggleButton gommeModeB = new JToggleButton("Gomme");
    gommeModeB.addActionListener(modeListener);
    this.gommeModeB = gommeModeB;
    nPan.add(gommeModeB);

    String[] figureList = {"Ligne", "Rectangle", "Cercle", "Ellipse", "Polygone"};
    JComboBox figureB = new JComboBox(figureList);
    figureB.addActionListener(new FigureListener());
    nPan.add(figureB);

    String[] couleurList = {"Noir", "Rouge", "Vert", "Bleu", "Jaune", "Orange", "Rose", "Magenta", "Gris"};
    JComboBox couleurB = new JComboBox(couleurList);
    couleurB.addActionListener(new CouleurListener());
    nPan.add(couleurB);

    JSpinner tailleB = new JSpinner(new SpinnerNumberModel(2, 1, 30, 1));
    tailleB.addChangeListener(new TailleListener());
    nPan.add(tailleB);

    JToggleButton remplirB = new JToggleButton("Remplir");
    remplirB.addActionListener(new RemplirListener());
    nPan.add(remplirB);

    JButton dessinerB = new JButton("Dessiner");
    dessinerB.addActionListener(new DessinerListener());
    nPan.add(dessinerB);

    JButton retourB = new JButton("Retour");
    retourB.addActionListener(new RetourListener());
    nPan.add(retourB);

    JButton effacerB = new JButton("Effacer");
    effacerB.addActionListener(new EffacerListener());
    nPan.add(effacerB);

    this.add(nPan, BorderLayout.NORTH);
  }


  public static void main(String[] args) {
    JFrame window = new Fenetre();
  }

  class CurseurListener extends MouseAdapter {


    public void mousePressed(MouseEvent e){
      if (mode == CRAYON) {
        element.add(new Crayon(e.getX(), e.getY(), true, couleur, taille, count));
        refreshZoneDessin();
        repaint();
      }


      else if (mode == GOMME) {
        element.add(new Crayon(e.getX(), e.getY(), true, Color.WHITE, taille, count));
        refreshZoneDessin();
        repaint();
      }


      else if (mode == FIGURE){
        if (figure == "Polygone"){
          x[nPoint] = e.getX();
          y[nPoint] = e.getY();
          nPoint++;
          if (nPoint == 1000){
            element.add(new Polygone(x, y, nPoint, remplir, couleur, taille, count));
            nPoint = 0;
            x = new int[10];
            y = new int[10];
            refreshZoneDessin();
            repaint();
          }

        }

        else {
        x1 = new Integer(e.getX());
        y1 = new Integer(e.getY());
        element.add(null);
        }
      }
    }

    public void mouseReleased(MouseEvent e){
      if (mode == FIGURE && figure != "Polygone"){
        int x2 = e.getX();
        int y2 = e.getY();

        if (figure == "Rectangle")
          element.set(element.size() - 1, new Rectangle(x1.intValue(), y1.intValue(), x2, y2, remplir, couleur, taille, count));
        else if (figure == "Ligne")
          element.set(element.size() - 1, new Ligne(x1.intValue(), y1.intValue(), x2, y2, couleur, taille, count));
        else if (figure == "Ellipse")
          element.set(element.size() - 1, new Ellipse(x1.intValue(), y1.intValue(), x2, y2, remplir, couleur, taille, count));
        else
          element.set(element.size() - 1, new Cercle(x1.intValue(), y1.intValue(), x2, y2, remplir, couleur, taille, count));

        refreshZoneDessin();
        repaint();
      }


      count += 1;
    }
  }


  class DrawListener extends MouseMotionAdapter{
    public void mouseDragged(MouseEvent e){
      if (mode == CRAYON) {
        element.add(new Crayon(e.getX(), e.getY(), true, couleur, taille, count));
        refreshZoneDessin();
        repaint();
      }

      else if (mode == GOMME) {
        element.add(new Crayon(e.getX(), e.getY(), true, Color.WHITE, taille, count));
        refreshZoneDessin();
        repaint();
      }

      else if (mode == FIGURE && figure != "Polygone") {
        int x2 = e.getX();
        int y2 = e.getY();

        if (figure == "Rectangle")
          element.set(element.size()-1, new Rectangle(x1.intValue(), y1.intValue(), x2, y2, remplir, couleur, taille, count));
        else if (figure == "Ligne")
          element.set(element.size()-1, new Ligne(x1.intValue(), y1.intValue(), x2, y2, couleur, taille, count));
        else if (figure == "Ellipse")
          element.set(element.size()-1, new Ellipse(x1.intValue(), y1.intValue(), x2, y2, remplir, couleur, taille, count));
        else
          element.set(element.size()-1, new Cercle(x1.intValue(), y1.intValue(), x2, y2, remplir, couleur, taille, count));

        refreshZoneDessin();
        repaint();
      }
    }
  }

  class RemplirListener implements ActionListener{
    public void actionPerformed(ActionEvent e){
      AbstractButton abstractButton = (AbstractButton) e.getSource();
      remplir = abstractButton.getModel().isSelected();
    }
  }

  class RetourListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      if (!element.isEmpty()){
        int id = element.get(element.size()-1).groupID;
        element.remove(element.size()-1);
        boolean done = false;
        while(!element.isEmpty() && !done){
          if (element.get(element.size()-1).groupID == id)
            element.remove(element.size()-1);
          else
            done = true;
        }
        refreshZoneDessin();
        repaint();
      }
    }
  }

  class DessinerListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      element.add(new Polygone(x, y, nPoint, remplir, couleur, taille, count));
      nPoint = 0;
      x = new int[10];
      y = new int[10];
      refreshZoneDessin();
      repaint();
    }
  }



  class EffacerListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      while (!element.isEmpty())
        element.remove(element.size()-1);
      refreshZoneDessin();
      repaint();
    }
  }


  class FigureListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      JComboBox cBox = (JComboBox) e.getSource();
      figure = (String)cBox.getSelectedItem();
      mode = FIGURE;

      crayonModeB.setSelected(false);
      figureModeB.setSelected(true);
      gommeModeB.setSelected(false);
    }
  }

  class CouleurListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      JComboBox cBox = (JComboBox) e.getSource();
      String couleurString = (String)cBox.getSelectedItem();

      if (couleurString == "Noir")
        couleur = Color.BLACK;

      else if (couleurString == "Rouge")
        couleur = Color.RED;

      else if (couleurString == "Vert")
        couleur = Color.GREEN;

      else if (couleurString == "Bleu")
        couleur = Color.BLUE;

      else if (couleurString == "Jaune")
        couleur = Color.YELLOW;

      else if (couleurString == "Orange")
        couleur = Color.ORANGE;

      else if (couleurString == "Rose")
        couleur = Color.PINK;

      else if (couleurString == "Magenta")
        couleur = Color.MAGENTA;

      else if (couleurString == "Gris")
        couleur = Color.LIGHT_GRAY;

    }
  }

  class TailleListener implements ChangeListener {
    public void stateChanged(ChangeEvent e) {
      JSpinner spinner = (JSpinner) e.getSource();
      taille = (int)spinner.getValue();
    }
  }

  class ModeListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      JToggleButton tButton = (JToggleButton) e.getSource();
      if (tButton.isSelected()){
        if (tButton == crayonModeB){
          figureModeB.setSelected(false);
          gommeModeB.setSelected(false);
          mode = CRAYON;
        }

        else if (tButton == figureModeB){
          crayonModeB.setSelected(false);
          gommeModeB.setSelected(false);
          mode = FIGURE;
        }

        else{
          crayonModeB.setSelected(false);
          figureModeB.setSelected(false);
          mode = GOMME;
        }
      }

      else{
        tButton.setSelected(true);
      }
    }
  }
}
