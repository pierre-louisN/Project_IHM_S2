import java.awt.Color;
import java.awt.*;

public class Crayon extends Figure {
  public int x;
  public int y;

  public Crayon(int x, int y, boolean rempli, Color couleur, int taille, int groupID) {
    super(rempli, couleur, taille, groupID);
    this.x = x;
    this.y = y;
  }

  public void dessiner(Graphics g) {
    g.setColor(this.couleur);

    g.fillOval(x - (taille/2), y - (taille/2), taille, taille);
  }

}