import java.awt.Color;
import java.awt.*;
import java.lang.Math;

public class Rectangle extends Figure{
  public int x1;
  public int y1;
  public int x2;
  public int y2;

  public Rectangle(int x1, int y1, int x2, int y2, boolean rempli, Color couleur, int taille, int groupID){
    super(rempli, couleur, taille, groupID);
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;
  }

  public void dessiner(Graphics g){
    g.setColor(this.couleur);
    ((Graphics2D) g).setStroke(new BasicStroke(this.taille));
    int xPos = this.x1;
    int yPos = this.y1;
    if (this.x2 < this.x1)
      xPos = this.x2;
    if (this.y2 < this.y1)
      yPos = this.y2;

    if (this.rempli)
      g.fillRect(xPos, yPos, Math.abs(this.x1 - this.x2), Math.abs(this.y1 - this.y2));
    else
      g.drawRect(xPos, yPos, Math.abs(this.x1 - this.x2), Math.abs(this.y1 - this.y2));
  }

}
